
    //  Fixed navigation bar codes 
$(document).ready(function() {

     $('.product').slick({
        slidesToShow: 4,
	  	slidesToScroll: 1,
        dots: false,
	  	arrows: false,
        autoplay: true,
		responsive: [
            {
                breakpoint: 992,
                  settings: {
                    slidesToShow: 3
                  }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1
                }
            }
        ]
      });
    $('.product-2').slick({
        slidesToShow: 4,
	  	slidesToScroll: 1,
        dots: false,
        infinite: true,
	  	arrows: false,
        autoplay: true,
		responsive: [
            {
                breakpoint: 992,
                settings: {
                    slidesToShow:3
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1
                }
            }
        ]
      });
     $('.product_details').slick({
        slidesToShow: 3,
	  	slidesToScroll: 1,
        dots: false,
        infinite: true,
	  	arrows: false,
        autoplay: true,
		responsive: [
            {
                breakpoint: 992,
                settings: {
                    slidesToShow:2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1
                }
            }
        ]
      });
     
});
$(document).ready(function(){
    $offset = $('#navbar-header').offset().top;
});
$(window).scroll(function(){
    $scrolling = $(this).scrollTop();
    if($scrolling >= $offset){
        $('#navbar-header').addClass('navbar-fixed-top');
    }
    else{
        $('#navbar-header').removeClass('navbar-fixed-top');
    }
});
        
        
        
        
        
        
        
        
        
        
        
        
 