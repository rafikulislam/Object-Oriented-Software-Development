<?php
	$con=mysqli_connect("localhost","root","","rma");
	if(!$con){
		echo "connection error";
		}
?>