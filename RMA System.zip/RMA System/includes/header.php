<!DOCTYPE html>
<html>
    <head>
        <title>Furniture.com</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="css/font-awesome.min.css"/>
        <link type="text/css" rel="stylesheet" href="css/slick.css">    
        <link type="text/css" rel="stylesheet" href="css/style.css">
        <link type="text/css" rel="stylesheet" href="css/media.min.css">

        <script type="text/javascript" src="js/jquery-1.12.2.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/slick.min.js"></script>
        <script type="text/javascript" src="js/custom.js"></script>
    </head>
    <body>
        <header>
            <section id="header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4 col-sm-12 hidden-xs text-center p0">
                            <a href="index.php"><img src="images/brand-5f42bbbe.png" class="img-responsive" alt="logo.png"></a>
                        </div>
                        <div class="col-md-8 col-sm-12 mb_dvice p0">
                            <ul class="list-inline navbar-right">
                                <li><a href="#">About us</a></li>
                                <li><a href="#">Contact us</a></li>
                                <li><a href="#">Feedback</a></li>
                                <li><a href="">Hotline : <span>+88 017 29346959</span></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>
            <section id="navbar-header">
                <nav class="navbar-default">
                  <div class="container nav_border">
                    <div class="row">
                        <div class="navbar-header">
                          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                          </button>
                          <a class="hidden-md hidden-lg hidden-sm visible-xs" href="index.html"><img src="images/brand-5f42bbbe.png" class="img-responsive" alt="logo.png"></a>
                        </div>
                        <!-- nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                          <ul class="nav navbar-nav navbar-right">
                            <li><a href="index.php">HOME</a></li>
                            <li><a href="#">ROOM CATEGORY</a></li>
                            <li><a href="status.php">VIEW ROOM STATUS</a></li>
                            <li><a href="login.php">RESERVE ANYONE</a></li>
                            <li><a href="login.php">LOGIN</a></li>
                            <form class="navbar-form navbar-left" role="search">
                                <div class="form-group">
                                  <input type="text" class="form-control" placeholder="Search">
                                </div>
                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                            </form>
                          </ul>
                        </div>
                    </div>
                  </div>
                </nav>
            </section>
        </header><!-- header part ends -->